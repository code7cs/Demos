export interface ITodo {
  text: string;
  completed?: boolean;
}
