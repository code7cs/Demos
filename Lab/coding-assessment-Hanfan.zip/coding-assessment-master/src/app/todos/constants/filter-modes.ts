export type FILTER_MODES = 'All' | 'Active' | 'Completed';
